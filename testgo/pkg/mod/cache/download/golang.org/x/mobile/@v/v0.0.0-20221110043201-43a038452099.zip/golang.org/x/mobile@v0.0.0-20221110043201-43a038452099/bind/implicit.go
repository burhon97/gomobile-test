// This file imports implicit dependencies required by generated code.

//go:build mobile_implicit
// +build mobile_implicit

package bind

import (
	_ "golang.org/x/mobile/bind/seq"
)
